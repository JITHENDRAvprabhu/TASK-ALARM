let alarmInterval; // To store the interval ID

document.getElementById('alarmForm').addEventListener('submit', function (e) {
  e.preventDefault();

  const taskName = document.getElementById('taskName').value;
  const taskDescription = document.getElementById('taskDescription').value;
  const alarmTime = new Date(document.getElementById('alarmTime').value).getTime();
  const now = new Date().getTime();

  if (!taskName || !alarmTime) {
    alert('Please enter a task name and alarm time.');
    return;
  }

  if (alarmTime < now) {
    alert('Alarm time must be in the future.');
    return;
  }

  const timeToAlarm = alarmTime - now;
  document.getElementById('message').innerText = `Alarm set for "${taskName}" at ${new Date(alarmTime).toLocaleTimeString()}.`;

  setTimeout(() => {
    // Show alert and start alarm
    alert(`Time for your task: ${taskName}\n${taskDescription}`);

    const alarmSound = document.getElementById('alarmSound');
    const cancelButton = document.getElementById('cancelButton');

    // Play the alarm repeatedly
    alarmInterval = setInterval(() => {
      alarmSound.play();
    }, 3000); // Adjust interval duration as needed

    // Show the Cancel button
    cancelButton.style.display = 'block';
  }, timeToAlarm);
});

// Cancel the alarm
document.getElementById('cancelButton').addEventListener('click', () => {
  clearInterval(alarmInterval); // Stop the alarm
  const alarmSound = document.getElementById('alarmSound');
  alarmSound.pause(); // Stop any sound currently playing
  alarmSound.currentTime = 0; // Reset the sound
  document.getElementById('cancelButton').style.display = 'none'; // Hide Cancel button
  document.getElementById('message').innerText = 'Alarm canceled.';
});

// Request Notification permission on page load
if (Notification.permission === "default") {
  Notification.requestPermission().then(permission => {
    console.log(`Notification permission: ${permission}`);
  });
}
